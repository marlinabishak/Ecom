"""Seed default users + sample catalog data for SQLAlchemy. Idempotent."""
import os
from datetime import datetime, timezone
from db import SessionLocal
from sql_models import User, Category, Product
from security import hash_password, verify_password

SAMPLE_CATEGORIES = [
    {"name": "Watches", "slug": "watches", "description": "Premium timepieces.",
     "image": "https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80"},
    {"name": "Apparel", "slug": "apparel", "description": "Modern fashion for every day.",
     "image": "https://images.unsplash.com/photo-1715541448446-3369e1cc0ee9?w=800&q=80"},
    {"name": "Accessories", "slug": "accessories", "description": "Curated accessories.",
     "image": "https://images.unsplash.com/photo-1662893992324-397132d77dbd?w=800&q=80"},
    {"name": "Electronics", "slug": "electronics", "description": "Tech that delights.",
     "image": "https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=800&q=80"},
]

SAMPLE_PRODUCTS = [
    {"name": "Chronos Automatic Watch", "slug": "chronos-automatic-watch",
     "description": "Precision Swiss movement, sapphire crystal, 316L steel case.",
     "price": 24999, "compare_price": 29999, "stock": 15, "category_slug": "watches",
     "brand": "Chronos", "featured": True, "tags": ["luxury", "automatic"],
     "images": ["https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=1200&q=80",
                "https://images.unsplash.com/photo-1582150264904-e0bea5ef0ad1?w=1200&q=80"]},
    {"name": "Meridian Chronograph", "slug": "meridian-chronograph",
     "description": "Chronograph with brown leather strap, water resistant to 100m.",
     "price": 18999, "compare_price": 21999, "stock": 20, "category_slug": "watches",
     "brand": "Meridian", "featured": True, "tags": ["chronograph"],
     "images": ["https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=1200&q=80"]},
    {"name": "Silver Link Bracelet Watch", "slug": "silver-link-bracelet-watch",
     "description": "Elegant round face with polished link bracelet.",
     "price": 14999, "stock": 25, "category_slug": "watches",
     "brand": "Chronos", "featured": False, "tags": ["silver"],
     "images": ["https://images.unsplash.com/photo-1582150264904-e0bea5ef0ad1?w=1200&q=80"]},
    {"name": "Minimalist Black Tee", "slug": "minimalist-black-tee",
     "description": "Heavyweight organic cotton, boxy fit, made in Portugal.",
     "price": 1499, "compare_price": 1999, "stock": 100, "category_slug": "apparel",
     "brand": "Studio Noir", "featured": True, "tags": ["tee", "cotton"],
     "images": ["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1200&q=80"]},
    {"name": "Merino Wool Sweater", "slug": "merino-wool-sweater",
     "description": "Sustainably sourced merino wool sweater, machine washable.",
     "price": 4999, "stock": 40, "category_slug": "apparel",
     "brand": "Nord", "featured": False, "tags": ["wool"],
     "images": ["https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=1200&q=80"]},
    {"name": "Leather Weekender Bag", "slug": "leather-weekender-bag",
     "description": "Full-grain leather bag with brass hardware and cotton lining.",
     "price": 8999, "compare_price": 10999, "stock": 12, "category_slug": "accessories",
     "brand": "Atelier", "featured": True, "tags": ["leather", "bag"],
     "images": ["https://images.unsplash.com/photo-1547949003-9792a18a2601?w=1200&q=80"]},
    {"name": "Aviator Sunglasses", "slug": "aviator-sunglasses",
     "description": "UV400 protection with titanium frame.",
     "price": 3499, "stock": 60, "category_slug": "accessories",
     "brand": "Solar", "featured": False, "tags": ["sunglasses"],
     "images": ["https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=1200&q=80"]},
    {"name": "Wireless ANC Headphones", "slug": "wireless-anc-headphones",
     "description": "Over-ear wireless headphones with 40h battery life.",
     "price": 12999, "compare_price": 15999, "stock": 30, "category_slug": "electronics",
     "brand": "Sonic", "featured": True, "tags": ["audio"],
     "images": ["https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=1200&q=80"]},
]

def _seed_user(db, email: str, password: str, name: str, role: str):
    existing = db.query(User).filter(User.email == email).first()
    hashed = hash_password(password)
    if not existing:
        u = User(email=email, password_hash=hashed, name=name, role=role)
        db.add(u)
    elif not verify_password(password, existing.password_hash) or existing.role != role:
        existing.password_hash = hashed
        existing.role = role
        existing.name = name

def seed_all():
    db = SessionLocal()
    try:
        _seed_user(db, os.environ.get("SUPER_ADMIN_EMAIL", "super@nordic.com"), os.environ.get("SUPER_ADMIN_PASSWORD", "secret"), "Super Admin", "super_admin")
        _seed_user(db, os.environ.get("ADMIN_EMAIL", "admin@nordic.com"), os.environ.get("ADMIN_PASSWORD", "secret"), "Store Admin", "admin")
        _seed_user(db, os.environ.get("SUPPORT_EMAIL", "support@nordic.com"), os.environ.get("SUPPORT_PASSWORD", "secret"), "Support Exec", "support")
        _seed_user(db, os.environ.get("DEMO_USER_EMAIL", "demo@nordic.com"), os.environ.get("DEMO_USER_PASSWORD", "secret"), "Demo Customer", "customer")
        
        # Categories
        for cat in SAMPLE_CATEGORIES:
            existing = db.query(Category).filter(Category.slug == cat["slug"]).first()
            if not existing:
                c = Category(**cat)
                db.add(c)
                
        db.commit() # commit categories first for foreign keys
        
        # Products
        for p in SAMPLE_PRODUCTS:
            existing = db.query(Product).filter(Product.slug == p["slug"]).first()
            if not existing:
                pr = Product(**p)
                db.add(pr)
                
        db.commit()
    finally:
        db.close()

if __name__ == "__main__":
    seed_all()