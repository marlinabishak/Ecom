import React, { useState, useEffect } from 'react';
import { Users, ShoppingBag, DollarSign, Activity, AlertTriangle, MessageSquare, BarChart } from 'lucide-react';
import api from '../../lib/api';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/admin/stats')
      .then(res => setStats(res.data))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div style={{ padding: '4rem', display: 'flex', justifyContent: 'center' }}><div className="spinner"></div></div>;
  }

  const metrics = [
    { label: 'Total Revenue', value: `₹${stats?.revenue?.toLocaleString() || 0}`, icon: <DollarSign size={24} />, color: 'var(--accent-primary)' },
    { label: 'Total Orders', value: stats?.total_orders || 0, icon: <ShoppingBag size={24} />, color: 'var(--info)' },
    { label: 'Total Customers', value: stats?.total_customers || 0, icon: <Users size={24} />, color: 'var(--warning)' },
    { label: 'Open Tickets', value: stats?.open_tickets || 0, icon: <Activity size={24} />, color: '#8b5cf6' },
  ];

  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>Admin Dashboard</h1>
        <p style={{ color: 'var(--text-secondary)' }}>Live overview of your store's performance.</p>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {metrics.map(stat => (
          <div key={stat.label} className="card" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: 'var(--radius-md)', background: `${stat.color}22`, color: stat.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {stat.icon}
            </div>
            <div>
              <div style={{ color: 'var(--text-muted)', fontSize: '0.9rem', fontWeight: 500 }}>{stat.label}</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700 }}>{stat.value}</div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-3 gap-6">
        <div className="card" style={{ padding: '2rem', gridColumn: 'span 2' }}>
          <div className="flex items-center gap-2 mb-6">
            <BarChart className="text-accent-primary" />
            <h2 style={{ fontSize: '1.25rem' }}>Recent Daily Sales</h2>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', height: '250px', gap: '1rem', marginTop: '2rem' }}>
            {stats?.daily_sales?.length > 0 ? stats.daily_sales.map(day => {
              const maxTotal = Math.max(...stats.daily_sales.map(d => d.total));
              const heightPct = maxTotal > 0 ? (day.total / maxTotal) * 100 : 0;
              return (
                <div key={day.date} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', fontWeight: 600 }}>₹{day.total}</div>
                  <div style={{ width: '100%', height: `${heightPct}%`, minHeight: '10px', background: 'var(--accent-primary)', borderRadius: '4px 4px 0 0', opacity: 0.8, transition: 'height 0.5s ease-out' }}></div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{day.date.split('-').slice(1).join('/')}</div>
                </div>
              );
            }) : (
              <div style={{ width: '100%', textAlign: 'center', color: 'var(--text-muted)', alignSelf: 'center' }}>No recent sales data.</div>
            )}
          </div>
        </div>
        
        <div className="card" style={{ padding: '2rem' }}>
           <h2 style={{ fontSize: '1.25rem', marginBottom: '1.5rem' }}>Action Alerts</h2>
           <div className="flex flex-col gap-4">
             <div style={{ padding: '1rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', gap: '1rem', borderLeft: '4px solid var(--warning)' }}>
               <AlertTriangle size={24} style={{ color: 'var(--warning)' }} />
               <div>
                 <div style={{ fontWeight: 600 }}>Low Stock Products</div>
                 <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{stats?.low_stock || 0} items need restocking</div>
               </div>
             </div>
             
             <div style={{ padding: '1rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', gap: '1rem', borderLeft: '4px solid var(--info)' }}>
               <MessageSquare size={24} style={{ color: 'var(--info)' }} />
               <div>
                 <div style={{ fontWeight: 600 }}>Pending Feedback</div>
                 <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{stats?.pending_feedback || 0} unread messages</div>
               </div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
