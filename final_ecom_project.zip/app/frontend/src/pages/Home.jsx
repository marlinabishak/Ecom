import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, ShieldCheck, Truck } from 'lucide-react';
import api from '../lib/api';
import ProductCard from '../components/ProductCard';

const Home = () => {
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const res = await api.get('/api/products?featured=true&limit=4');
        setFeatured(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  return (
    <div className="page-enter">
      {/* Hero Section */}
      <section style={{ 
        position: 'relative', height: '80vh', display: 'flex', alignItems: 'center',
        background: 'linear-gradient(to right, var(--bg-primary) 20%, rgba(15,17,21,0.5)), url(https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80) center/cover'
      }}>
        <div className="container">
          <div style={{ maxWidth: '600px' }}>
            <h1 style={{ fontSize: '4rem', marginBottom: '1.5rem', lineHeight: 1.1 }}>
              Elevate Your <span className="text-accent-gradient">Lifestyle</span>
            </h1>
            <p style={{ fontSize: '1.2rem', color: 'var(--text-secondary)', marginBottom: '2.5rem' }}>
              Discover our premium collection of meticulously crafted products designed for the modern aesthetic.
            </p>
            <div className="flex gap-4">
              <Link to="/shop" className="btn btn-primary" style={{ padding: '1rem 2rem', fontSize: '1.1rem' }}>
                Shop Collection <ArrowRight size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '4rem 0', background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-light)' }}>
        <div className="container grid grid-cols-3 gap-8">
          <div className="flex flex-col items-center gap-4 text-center">
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.1)', color: 'var(--accent-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Truck size={32} />
            </div>
            <h3 style={{ fontSize: '1.2rem' }}>Free Express Shipping</h3>
            <p style={{ color: 'var(--text-muted)' }}>On all orders over ₹999 across India.</p>
          </div>
          <div className="flex flex-col items-center gap-4 text-center">
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(59, 130, 246, 0.1)', color: 'var(--info)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ShieldCheck size={32} />
            </div>
            <h3 style={{ fontSize: '1.2rem' }}>Secure Payments</h3>
            <p style={{ color: 'var(--text-muted)' }}>100% secure checkout powered by Razorpay.</p>
          </div>
          <div className="flex flex-col items-center gap-4 text-center">
            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'rgba(245, 158, 11, 0.1)', color: 'var(--warning)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Star size={32} />
            </div>
            <h3 style={{ fontSize: '1.2rem' }}>Premium Quality</h3>
            <p style={{ color: 'var(--text-muted)' }}>Handpicked selection of the finest goods.</p>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section style={{ padding: '6rem 0' }}>
        <div className="container">
          <div className="flex justify-between items-center" style={{ marginBottom: '3rem' }}>
            <h2 style={{ fontSize: '2.5rem' }}>Featured <span className="text-accent-gradient">Products</span></h2>
            <Link to="/shop" style={{ color: 'var(--accent-primary)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              View All <ArrowRight size={18} />
            </Link>
          </div>
          
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '4rem' }}><div className="spinner"></div></div>
          ) : (
            <div className="grid grid-cols-4 gap-6">
              {featured.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;
